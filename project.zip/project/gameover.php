<?php
session_start();
$finalScore = $_SESSION['score'];
// Reset game state for a new game
$_SESSION['score'] = 0;
$_SESSION['lives'] = 3;

// Display final score and a restart link
echo "Game Over. Your final score was: $finalScore<br>";
echo "<a href='index.php'>Restart Game</a>";
?>