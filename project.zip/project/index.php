<?php
session_start();

include 'database.php';

if (!isset($_SESSION['total_level'])) {
    $_SESSION['total_level'] = 0;
}

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_SESSION['game'])) {
    $_SESSION['game'] = [
        'lives' => 3,
        'score' => 0,
        'highscore' => $_SESSION['highscore'] ?? 0,
        'points' => [],
        'nextUpdateTime' => time() + 2,
        'pointIncreaseTime' => time() + 10,
        'pointFrequency' => 2,
    ];
}

$score = $_SESSION['score'];
$levelIncrement = floor($score / 10);
$level = $_SESSION['total_level'] + $levelIncrement;
$xpForNextLevel = 10;
$progressTowardsNextLevel = $score % $xpForNextLevel;
$progressPercentage = ($progressTowardsNextLevel / $xpForNextLevel) * 100;

$username = $_SESSION['username'];
$sql = "SELECT username, title, highscore, profile_pic FROM users WHERE username = :username";
$stmt = $pdo->prepare($sql);
$stmt->execute(['username' => $username]);
$userInfo = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$userInfo) {
    echo "User not found!";
    exit;
}

if (empty($userInfo['title'])) {
    $userInfo['title'] = 'Beginner';
}

if (empty($userInfo['profile_pic'])) {
    $userInfo['profile_pic'] = 'default.jpg';
}

if (!isset($_SESSION['lives'])) {
    $_SESSION['lives'] = 3;
    $_SESSION['score'] = 0;
    $_SESSION['highscore'] = $userInfo['highscore'] ?? 0;
}

if (isset($_GET['update'])) {
    $update = $_GET['update'];
    $value = intval($_GET['value']);
    switch ($update) {
        case 'score':
            $_SESSION['score'] = $value;
            if ($value > $_SESSION['highscore']) {
                $_SESSION['highscore'] = $value;
            }
            break;
        case 'lives':
            $_SESSION['lives'] = $value;
            break;
    }
}

function updateHighscore($username, $newHighscore) {
    global $pdo;
    $sql = "UPDATE users SET highscore = :highscore WHERE id = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['highscore' => $newHighscore, 'username' => $username]);
}

function insertNewScore($username, $score) {
    global $pdo;
    $sql = "INSERT INTO scores (user_id, score) VALUES (:username, :score)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['username' => $username, 'score' => $score]);
}

function checkAndUpdateHighscore($username, $currentScore) {
    global $pdo;
    $sql = "SELECT highscore FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['username' => $username]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($result && $currentScore > $result['highscore']) {
        updateHighscore($username, $currentScore);
    }
}

function updateUserInformation($username, $password, $title, $level, $profilePic) {
    global $pdo;
    $sql = "UPDATE users SET username = :username, password = :password, title = :title, level = :level, profile_pic = :profilePic WHERE id = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'username' => $username,
        'password' => $password,
        'title' => $title,
        'level' => $level,
        'profilePic' => $profilePic,
    ]);
}

if (isset($_GET['missed'])) {
    $_SESSION['lives']--;

    if ($_SESSION['lives'] <= 0) {
        if ($_SESSION['game']['score'] > $_SESSION['game']['highscore']) {
            $_SESSION['game']['highscore'] = $_SESSION['game']['score'];
        }
        $_SESSION['total_level'] = $level;

        $username = $_SESSION['username'];
        $currentScore = $_SESSION['game']['score'];
        checkAndUpdateHighscore($username, $currentScore);

        $_SESSION['score'] = 0;
        $_SESSION['lives'] = 3;
    }
}

$score = $_SESSION['score'];
$levelIncrement = floor($score / 10);
$level = $_SESSION['total_level'] + $levelIncrement;

if (!isset($_SESSION['game'])) {
    $_SESSION['game'] = [
        'lives' => 3,
        'score' => 0,
        'highscore' => $_SESSION['highscore'] ?? 0,
        'points' => [],
        'nextUpdateTime' => time() + 2,
        'pointIncreaseTime' => time() + 10,
        'pointFrequency' => 2,
    ];
}

if (isset($_GET['select'])) {
    $selectedItem = $_GET['select'];
    switch ($selectedItem) {
        case 'pointColor':
            $_SESSION['pointColor'] = '#FF0000';
            break;
        case 'profilePicture':
            $_SESSION['profilePicture'] = 'new_picture.jpg';
            break;
        case 'title':
            $_SESSION['title'] = 'New Title';
            break;
    }
}

$unlockables = [
    'Blue Point Color' => 2,
    'New Profile Pic' => 5,
    'New Title' => 3,
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aim Trainer</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            background-image: url('background.jpg');
            background-size: cover;
            background-position: center;
        }
    </style>
</head>
<body>
<div class="profile-section">
    <img src="<?php echo htmlspecialchars($userInfo['profile_pic']); ?>" alt="Profile Picture" class="profile-pic">
    <div class="profile-info">
        <p>Username: <span class="username" id="username"><?php echo htmlspecialchars($userInfo['username']); ?></span></p>
        <p>Level: <span class="level" id="level"><?php echo htmlspecialchars($level); ?></span></p>
        <div class="xp-bar">
            <div class="xp-progress" style="width: <?php echo htmlspecialchars($progressPercentage); ?>%;"></div>
        </div>
        <p>Title: <span class="title" id="title"><?php echo htmlspecialchars($userInfo['title']); ?></span></p>
    </div>
</div>

<?php
$pointX = rand(0, 90);
$pointY = rand(0, 90);

if (isset($_GET['pointClicked'])) {
    $_SESSION['score'] += 1;
    header("Location: index.php");
    exit();
}
?>

<div class="main-game-area" id="main-game-area">
    <div class="game-board">
        <div class="game-header">
            <span>Highscore: <span id="highscore"><?php echo $_SESSION['highscore']; ?></span></span>
            <span>Score: <span id="score"><?php echo $_SESSION['score']; ?></span></span>
            <span class="lives">
                <?php for ($i = 0; $i < $_SESSION['lives']; $i++): ?>
                    <img src="heart.jpg" alt="Heart" class="heart">
                <?php endfor; ?>
            </span>
        </div>
        <div class="game-play-area" id="game-play-area" onclick="checkMiss(event)">
            <a href="index.php?pointClicked=true" class="point" style="position: absolute; top: <?= $pointY ?>%; left: <?= $pointX ?>%;"></a>
        </div>
    </div>
</div>

<script>
function checkMiss(event) {
    if (event.target === document.getElementById('game-play-area')) {
        window.location.href = 'index.php?missed=true';
    }
}
</script>

<?php
if (isset($_GET['select'])) {
    $selectedItem = $_GET['select'];
    switch ($selectedItem) {
        case 'pointColor':
            $_SESSION['pointColor'] = '#FF0000';
            break;
        case 'profilePicture':
            $_SESSION['profilePicture'] = 'new_picture.jpg';
            break;
        case 'title':
            $_SESSION['title'] = 'Mega Cool';
            break;
    }
}
?>

<div class="left-sidebar">
    <div class="sidebar-content">
        <h3></h3>
        <ul>
            <?php foreach ($unlockables as $item => $requiredLevel): ?>
                <?php if ($level >= $requiredLevel): ?>
                    <li><a href="index.php?select=<?= $item ?>" class="unlockable unlocked"><?= ucfirst($item) ?></a></li>
                <?php else: ?>
                    <li class="unlockable"><?= ucfirst($item) ?>
