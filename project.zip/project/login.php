<?php
session_start();

if (isset($_SESSION['username'])) {
    echo "User is already logged in. Redirecting to index.";
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    include 'database.php';

    $username = htmlspecialchars($username);

    $sql = "SELECT * FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['username'] = $username;
        $_SESSION['user_id'] = $user['id'];
        echo "Login successful. Redirecting to index.";
        header('Location: index.php');
        exit;
    } else {
        echo "Invalid username or password.";
    }
}

// Debugging: check if form submission is working and session is set correctly
if (!isset($_SESSION['username'])) {
    echo "Session 'username' not set.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form action="login.php" method="post">
            <div class="form-group">
                <input type="text" name="username" placeholder="Enter username" class="form-control" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Enter Password" class="form-control" required>
            </div>
            <div class="form-btn">
                <input type="submit" value="Login" class="btn btn-primary">
            </div>
        </form>
        <div>
            <p>Not registered yet? <a href="registration.php">Register Here</a></p>
        </div>
    </div>
</body>
</html>
