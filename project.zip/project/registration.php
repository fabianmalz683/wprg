<?php
session_start();
// If the user is already logged in, redirect to the index page
if (isset($_SESSION["username"])) { // Change to 'username' for consistency
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
            // Collect form data
            $username = trim($_POST["username"]);
            $password = $_POST["password"];
            $passwordRepeat = $_POST["repeat_password"];

            // Array to hold errors
            $errors = [];

            // Basic validation
            if (empty($username) || empty($password) || empty($passwordRepeat)) {
                $errors[] = "All fields are required.";
            }
            if (strlen($password) < 8) {
                $errors[] = "Password must be at least 8 characters long.";
            }
            if ($password !== $passwordRepeat) {
                $errors[] = "Passwords do not match.";
            }

            // If no errors, proceed to database interaction
            if (count($errors) === 0) {
                require_once "database.php";

                // Check if the username already exists
                $sql = "SELECT * FROM users WHERE username = ?";
                $stmt = mysqli_prepare($conn, $sql);
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "s", $username);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    if (mysqli_num_rows($result) > 0) {
                        $errors[] = "Username is already taken.";
                    } else {
                        // Insert the new user
                        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
                        $stmt = mysqli_prepare($conn, $sql);
                        if ($stmt) {
                            mysqli_stmt_bind_param($stmt, "ss", $username, $passwordHash);
                            mysqli_stmt_execute($stmt);
                            echo "<div class='alert alert-success'>You are registered successfully.</div>";
                            // Redirect to login page after successful registration
                            header("Location: login.php");
                            exit;
                        } else {
                            $errors[] = "Error: Could not prepare statement.";
                        }
                    }
                    mysqli_stmt_close($stmt);
                } else {
                    $errors[] = "Error: Could not prepare statement.";
                }
            }

            // Display any errors
            if (count($errors) > 0) {
                foreach ($errors as $error) {
                    echo "<div class='alert alert-danger'>$error</div>";
                }
            }
        }
        ?>
        <form action="registration.php" method="post">
            <div class="form-group">
                <input type="text" class="form-control" name="username" placeholder="Username:" value="<?php if (isset($username)) echo htmlspecialchars($username); ?>">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password:">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="repeat_password" placeholder="Repeat Password:">
            </div>
            <div class="form-btn">
                <input type="submit" class="btn btn-primary" value="Register" name="submit">
            </div>
        </form>
        <div>
            <p>Already Registered? <a href="login.php">Login Here</a></p>
        </div>
    </div>
</body>
</html>
