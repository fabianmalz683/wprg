document.addEventListener("DOMContentLoaded", function() {
    // Handle point clicks
    document.querySelectorAll(".point").forEach(point => {
        point.addEventListener("click", function() {
            let pointId = this.getAttribute("data-point-id");
            fetch(`game.php?pointClicked=1&pointId=${pointId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        this.remove();
                        document.getElementById("score").textContent = data.newScore;
                    }
                });
        });
    });

    // Function to update the game state (for example, after 2 seconds)
    function updateGame() {
        fetch("game.php?updateGame=1")
            .then(response => response.json())
            .then(data => {
                if (data.gameOver) {
                    alert("Game Over! Score: " + data.score + ", Highscore: " + data.highscore);
                    // Reload the page or redirect to start a new game
                    location.reload();
                } else {
                    // Update the game board with new points and lives
                    document.querySelector(".game-play-area").innerHTML = data.points.map(point => {
                        return `<div class="point" data-point-id="${point.id}" style="position: absolute; top: ${point.y}%; left: ${point.x}%; width: 20px; height: 20px;"></div>`;
                    }).join("");
                    document.querySelector(".lives").innerHTML = '<img src="heart.jpg" alt="Heart" class="heart">'.repeat(data.lives);
                    document.getElementById("score").textContent = data.score;
                    document.getElementById("highscore").textContent = data.highscore;

                    // Re-attach click handlers to new points
                    document.querySelectorAll(".point").forEach(point => {
                        point.addEventListener("click", function() {
                            let pointId = this.getAttribute("data-point-id");
                            fetch(`game.php?pointClicked=1&pointId=${pointId}`)
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        this.remove();
                                        document.getElementById("score").textContent = data.newScore;
                                    }
                                });
                        });
                    });
                }
            });
    }

    // Periodically update the game
    setInterval(updateGame, 2000);
});
